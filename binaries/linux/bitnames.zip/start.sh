#!/bin/bash

export QT_DEBUG_PLUGINS=1
export XDG_RUNTIME_DIR="/run/user/100"
/home/jdavis/.bitnames/usr/bin/bitnames-qt -conf=/home/jdavis/.bitnames/bitnames.conf
